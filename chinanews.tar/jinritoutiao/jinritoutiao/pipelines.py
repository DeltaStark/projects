# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
from scrapy.exporters import JsonLinesItemExporter
from scrapy.exporters import XmlItemExporter
from scrapy import signals
import datetime

class JinritoutiaoPipeline:
        def __init__(self):
            nowTime = datetime.datetime.now().strftime('%Y-%m-%d')
            self.fp = open(nowTime+'ChinaNews.xml', 'wb')
            #self.exporter = JsonLinesItemExporter(self.fp, ensure_ascii=False)
            self.exporter  = XmlItemExporter(self.fp,item_element="new",encoding='utf-8')
            self.exporter.start_exporting()

        def process_item(self, item, spider):
            if item['title']:
                self.exporter.export_item(item)
                return item
            else:
                return ''

        def close_spider(self, spider):
            self.exporter.finish_exporting()
            self.fp.close()

class XmlExportPipeline:
    def __init__(self):
        self.files = {}

    @classmethod
    def from_crawler(cls, crawler):
        pipeline = cls()
        crawler.signals.connect(pipeline.spider_opened, signals.spider_opened)
        crawler.signals.connect(pipeline.spider_closed, signals.spider_closed)
        return pipeline

    def spider_opened(self, spider):
        now = datetime.datetime.now().strftime('%Y-%m-%d')
        file = open(now+'chinanews.xml', 'w+b')
        self.files[spider] = file
        self.exporter = XmlItemExporter(file,item_element="new")
        self.exporter.start_exporting()

    def spider_closed(self, spider):
        self.exporter.finish_exporting()
        file = self.files.pop(spider)
        file.close()

    def process_item(self, item, spider):
        if item['title']:
            self.exporter.export_item(item)
            return item
        else:
            return ''




