# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
import datetime
from jinritoutiao.items import JinritoutiaoItem


class SouhuSpider(CrawlSpider):
    name = 'huanqiu'
    allowed_domains = ['china.com']
    start_urls = ['https://news.china.com/domestic/']
    currentday = datetime.datetime.now().strftime('%Y-%m-%d')
    currentday=currentday.replace('-','')
    rules = (
        Rule(LinkExtractor(allow=r'https://news.china.com/domestic/'), follow=True),
        Rule(LinkExtractor(allow=r'https://news.china.com/international/'), follow=True),
        Rule(LinkExtractor(allow=r'https://ent.china.com/'), follow=True),
        Rule(LinkExtractor(allow=r'https://finance.china.com/tech/'), follow=True),


        Rule(LinkExtractor(allow=r'/+china.com.+'+ currentday+'.+\.html'), callback="parse_detail",follow=False),
    )

    def parse_detail(self, response):

        title = response.xpath("//h1[@class='chan_newsTitle']/text()").get()
        pub_time = response.xpath("//div[@class='chan_newsInfo_source']/span/text()").getall()
        category = response.xpath("//div[@id='chan_breadcrumbs']/a/text").getall()
        abstract = response.xpath("//div[@class='chan_newsDetail']/p//text()").getall()[2]
        url =  response.urljoin(response.request.url)
        #     item = JinritoutiaoItem(category=category,pub_time=pub_time,title=title,abstract=abstract,url=url)
        #     yield item
        print(pub_time)
        print(category)
        print(abstract)
        print(title)
        print(url)
