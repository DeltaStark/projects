# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
import datetime
from jinritoutiao.items import JinritoutiaoItem


class SouhuSpider(CrawlSpider):
    name = 'souhu'
    allowed_domains = ['xfrb.com.cn']
    start_urls = ['http://www.xfrb.com.cn/category/article/1016']

    rules = (
        Rule(LinkExtractor(allow=r'/category/article.+'), follow=True),
        Rule(LinkExtractor(allow=r'/article.+\.html'), callback="parse_detail",follow=False),
    )

    def parse_detail(self, response):
        currentday = datetime.datetime.now().strftime('%Y-%m-%d')
        title = response.xpath("//h1[@class='margin-top-15']/text()").get()
        pub_time = response.xpath("//div[@class='cite']/cite/text()").getall()[0][:10]
        source = response.xpath("//div[@class='cite']/cite/text()").getall()[1]
        category = response.xpath('//div[@class="container"]/span/a//text()').getall()[1:]
        content = response.xpath("//div[@class='cont']/p/text()").getall()
        url =  response.urljoin(response.request.url)
        if currentday == pub_time:
            # print(category)
            # print(pub_time)
            # print(title)
            # print(source)
            # print(content)
            # print(url)
            item = JinritoutiaoItem(category=category,pub_time=pub_time,title=title,source=source,content=content,url=url)
            yield item

