# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
import datetime
from jinritoutiao.items import JinritoutiaoItem


class NewspiderSpider(CrawlSpider):
    name = 'chinanews'
    allowed_domains = ['chinanews.com']
    start_urls = ['http://www.chinanews.com/china/']
    #currentday = str(datetime.datetime.now().year)+'-'+str(datetime.datetime.now().month)+'-'+str(datetime.datetime.now().day)
    currentday = datetime.datetime.now().strftime('%Y/%m-%d')

    rules = (
        Rule(LinkExtractor(allow=r'http://www.chinanews.com/china/'),  follow=True),
        Rule(LinkExtractor(allow=r'http://www.chinanews.com/world/'), follow=True),
        Rule(LinkExtractor(allow=r'http://www.chinanews.com/society/'), follow=True),
        Rule(LinkExtractor(allow=r'http://www.chinanews.com/ent/'), follow=True),
        Rule(LinkExtractor(allow=r'http://www.chinanews.com/sports/'), follow=True),
        Rule(LinkExtractor(allow=r'http://www.chinanews.com/auto/'), follow=True),
        Rule(LinkExtractor(allow=r'http://www.chinanews.com/life/'), follow=True),
        Rule(LinkExtractor(allow=r'http://www.chinanews.com/gangao/'), follow=True),
        Rule(LinkExtractor(allow=r'.+chinanews.com/.+'+currentday+'.+\.shtml',deny=r' http://www.chinanews.com.+shipin.+'),callback="parse_chinanews",follow = False),


    )

    def parse_chinanews(self, response):
        title = response.xpath("//div[@class='content']/h1/text()").get()
        pub_time = response.xpath("//div[@class='left-time']/div[@class='left-t']/text()").get()
        time = pub_time.split(' ',1)[0]
        cat = response.xpath("//div[@id='nav_div']/div[@id='nav']/a/text()").getall()[-1]
        abstract = response.xpath("//div[@class='left_zw']/p/text()").getall()[1]
        url = response.urljoin(response.request.url)
        item = JinritoutiaoItem(cat=cat,time=time,title=title,abstract=abstract,url=url)
        yield item
