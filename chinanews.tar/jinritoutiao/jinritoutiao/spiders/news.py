# -*- coding: utf-8 -*-
import scrapy



class NewsSpider(scrapy.Spider):
    name = 'news'
    allowed_domains = ['huanqiu.com']
    start_urls = ['https://world.huanqiu.com/article/3yUGW3uMq6J']

    # def parse(self, response):
    #     title = response.xpath("//h1[@class='main-title']/text()").get()
    #     pub_time  = response.xpath("//span[@class='date']/text()").get()
    #     caption = response.xpath("//div[@class='channel-path']/a/text()").getall()
    #     content = response.xpath("//div[@class='article']/p//text()").get().strip()
    #     print(title,pub_time)
    #     print(caption)
    #     print(content)

    # def parse(self, response):
    #     title = response.xpath("//div[@class='text-title']/h1/text()").get().strip()
    #     time = response.xpath("//span[@class='time']/text()").get()
    #
    #     print(title,time)

    # def parse(self, response):
    #     title = response.xpath("//h1[@class='margin-top-15']/text()").get()
    #     pub_time = response.xpath("//div[@class='cite']/cite/text()").getall()[0]
    #     source = response.xpath("//div[@class='cite']/cite/text()").getall()[1]
    #     category = response.xpath('//div[@class="container"]/span/a//text()').getall()[1:]
    #     content = response.xpath("//div[@class='cont']/p/text()").getall()
    #     print(title)
    #     print(pub_time)
    #     print(category)
    #     print(source)
    #     print(content)
    def parse(self, response):
        categorys =response.xpath("//div[contains(@class,'submenu')]/a/@href").get()
        print(categorys)




