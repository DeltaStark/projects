# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
import datetime
from jinritoutiao.items import JinritoutiaoItem


class NewspiderSpider(CrawlSpider):
    name = 'newspider'
    allowed_domains = ['sina.com.cn']
    start_urls = ['http://mil.news.sina.com.cn/']
    #currentday = str(datetime.datetime.now().year)+'-'+str(datetime.datetime.now().month)+'-'+str(datetime.datetime.now().day)
    currentday = datetime.datetime.now().strftime('%Y-%m-%d')

    rules = (
        Rule(LinkExtractor(allow=r'http://mil.news.sina.com.cn/'),  follow=True),
        Rule(LinkExtractor(allow=r'https://news.sina.com.cn/china/'), follow=True),
        Rule(LinkExtractor(allow=r'http://news.sina.com.cn/world/'), follow=True),
        Rule(LinkExtractor(allow=r'http://sports.sina.com.cn/nba/'), follow=True),
        Rule(LinkExtractor(allow=r'http://ent.sina.com.cn/film/'), follow=True),
        Rule(LinkExtractor(allow=r'http://games.sina.com.cn/'), follow=True),
        Rule(LinkExtractor(allow=r'http://jiaju.sina.com.cn/'), follow=True),
        Rule(LinkExtractor(allow=r'http://auto.sina.com.cn/newcar/index.d.html'), follow=True),
        Rule(LinkExtractor(allow=r'http://auto.sina.com.cn/'), follow=True),
        Rule(LinkExtractor(allow=r'http://mobile.sina.com.cn/'), follow=True),
        Rule(LinkExtractor(allow=r'.+sina.com.cn/.+'+currentday+'.+\.shtml'),callback="parse_detail",follow = False),
    )

    def parse_detail(self, response):
        title = response.xpath("//h1[@class='main-title']/text()").get()
        pub_time = response.xpath("//span[@class='date']/text()").get()
        category = response.xpath("//div[@class='channel-path']/a/text()").getall()
        abstract = response.xpath("//div[@class='article']/p//text()").getall()[:2]
        url = response.urljoin(response.request.url)
        item = JinritoutiaoItem(category=category,pub_time=pub_time,title=title,abstract=abstract,url=url)
        yield item