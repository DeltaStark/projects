# sina-news-crawler
```shell
contrab -e
```
then do the automation.