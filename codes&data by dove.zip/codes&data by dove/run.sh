#!/bin/bash
source /home/sean/miniconda3/bin/activate 
conda activate crawler 

cd /home/sean/Developer/Crawler 
python3 getURLs.py
python3 GetNews.py

